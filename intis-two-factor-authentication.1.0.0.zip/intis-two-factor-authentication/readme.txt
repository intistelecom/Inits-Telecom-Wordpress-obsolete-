=== Intis Two Factor Authentication ===
Contributors: konstantinshlyk
Tags: 2-factor auth, sms, notifications
License: GPL2+
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Plugin for 2-factor authentication via SMS code by Intis Telecom. Plugin also allows send sms notification with WooCommerce order status.